﻿namespace appDados
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.buttonenviar = new System.Windows.Forms.Button();
            this.txtresultados = new System.Windows.Forms.TextBox();
            this.txtendereco = new System.Windows.Forms.TextBox();
            this.lblendereco = new System.Windows.Forms.Label();
            this.txttelefone = new System.Windows.Forms.TextBox();
            this.lbltelefone = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.lvlnome = new System.Windows.Forms.Label();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.buttonenviar);
            this.groupBox.Controls.Add(this.txtresultados);
            this.groupBox.Controls.Add(this.txtendereco);
            this.groupBox.Controls.Add(this.lblendereco);
            this.groupBox.Controls.Add(this.txttelefone);
            this.groupBox.Controls.Add(this.lbltelefone);
            this.groupBox.Controls.Add(this.txtnome);
            this.groupBox.Controls.Add(this.lvlnome);
            this.groupBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox.Location = new System.Drawing.Point(12, 12);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(776, 426);
            this.groupBox.TabIndex = 0;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Coleta de dados";
            // 
            // buttonenviar
            // 
            this.buttonenviar.Location = new System.Drawing.Point(24, 244);
            this.buttonenviar.Name = "buttonenviar";
            this.buttonenviar.Size = new System.Drawing.Size(201, 44);
            this.buttonenviar.TabIndex = 7;
            this.buttonenviar.Text = "Enviar";
            this.buttonenviar.UseVisualStyleBackColor = true;
            this.buttonenviar.Click += new System.EventHandler(this.buttonenviar_Click);
            // 
            // txtresultados
            // 
            this.txtresultados.Location = new System.Drawing.Point(24, 306);
            this.txtresultados.Multiline = true;
            this.txtresultados.Name = "txtresultados";
            this.txtresultados.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtresultados.Size = new System.Drawing.Size(388, 114);
            this.txtresultados.TabIndex = 6;
            this.txtresultados.TextChanged += new System.EventHandler(this.txtresultados_TextChanged);
            // 
            // txtendereco
            // 
            this.txtendereco.Location = new System.Drawing.Point(24, 198);
            this.txtendereco.Name = "txtendereco";
            this.txtendereco.Size = new System.Drawing.Size(247, 29);
            this.txtendereco.TabIndex = 5;
            // 
            // lblendereco
            // 
            this.lblendereco.AutoSize = true;
            this.lblendereco.Location = new System.Drawing.Point(24, 174);
            this.lblendereco.Name = "lblendereco";
            this.lblendereco.Size = new System.Drawing.Size(166, 21);
            this.lblendereco.TabIndex = 4;
            this.lblendereco.Text = "Digite seu endereço:";
            this.lblendereco.Click += new System.EventHandler(this.label3_Click);
            // 
            // txttelefone
            // 
            this.txttelefone.Location = new System.Drawing.Point(24, 132);
            this.txttelefone.Name = "txttelefone";
            this.txttelefone.Size = new System.Drawing.Size(247, 29);
            this.txttelefone.TabIndex = 3;
            // 
            // lbltelefone
            // 
            this.lbltelefone.AutoSize = true;
            this.lbltelefone.Location = new System.Drawing.Point(24, 108);
            this.lbltelefone.Name = "lbltelefone";
            this.lbltelefone.Size = new System.Drawing.Size(159, 21);
            this.lbltelefone.TabIndex = 2;
            this.lbltelefone.Text = "Digite seu telefone:";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(24, 65);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(247, 29);
            this.txtnome.TabIndex = 1;
            // 
            // lvlnome
            // 
            this.lvlnome.AutoSize = true;
            this.lvlnome.Location = new System.Drawing.Point(24, 41);
            this.lvlnome.Name = "lvlnome";
            this.lvlnome.Size = new System.Drawing.Size(247, 21);
            this.lvlnome.TabIndex = 0;
            this.lvlnome.Text = "Digite primeiro e ultimo nome:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox;
        private Button buttonenviar;
        private TextBox txtresultados;
        private TextBox txtendereco;
        private Label lblendereco;
        private TextBox txttelefone;
        private Label lbltelefone;
        private TextBox txtnome;
        private Label lvlnome;
    }
}