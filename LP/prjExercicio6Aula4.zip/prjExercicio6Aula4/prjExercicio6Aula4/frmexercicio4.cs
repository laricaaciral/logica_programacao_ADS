﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjExercicio6Aula4
{
    public partial class frmexercicio4 : Form
    {
        public frmexercicio4()
        {
            InitializeComponent();
        }
    }
}
